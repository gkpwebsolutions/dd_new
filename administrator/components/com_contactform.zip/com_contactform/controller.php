<?php
// No direct access
defined('_JEXEC') or die;

class ContactFormController extends JControllerLegacy
{
    public function submit()
    {
        // Get the POST data
        $input = JFactory::getApplication()->input;
        $name = $input->getString('name');
        $email = $input->getString('email');
        $message = $input->getString('message');

        // Call the model to save the message
        $model = $this->getModel('Message');
        $result = $model->saveMessage($name, $email, $message);

        // Redirect based on the result
        if ($result) {
            JFactory::getApplication()->enqueueMessage('Message sent successfully!');
        } else {
            JFactory::getApplication()->enqueueMessage('There was an error sending your message.', 'error');
        }

        // Redirect to the component's default view
        $this->setRedirect(JRoute::_('index.php?option=com_contactform'));
    }
}
