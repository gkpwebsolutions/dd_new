<?php
// No direct access
defined('_JEXEC') or die;

class ContactFormHelper
{
    /**
     * Saves the contact message to the database
     *
     * @param   string  $name     Name of the user
     * @param   string  $email    Email of the user
     * @param   string  $message  The message content
     *
     * @return  bool  True on success, false on failure
     */
    public static function saveMessage($name, $email, $message)
    {
        // Get the database object
        $db = JFactory::getDbo();

        // Sanitize input values
        $name = htmlspecialchars(strip_tags($name), ENT_QUOTES, 'UTF-8');
        $email = htmlspecialchars(strip_tags($email), ENT_QUOTES, 'UTF-8');
        $message = htmlspecialchars(strip_tags($message), ENT_QUOTES, 'UTF-8');

        // Prepare the query to insert the message into the database
        $query = $db->getQuery(true)
            ->insert($db->quoteName('w1h54__contact_messages')) // Table name
            ->columns($db->quoteName(array('name', 'email', 'message', 'created')))
            ->values($db->quote($name) . ',' . $db->quote($email) . ',' . $db->quote($message) . ',' . $db->quote(JFactory::getDate()->toSql()));

        // Set the query and execute it
        $db->setQuery($query);

        try {
            $db->execute(); // Execute the query
            return true;
        } catch (Exception $e) {
            // Handle errors (e.g. database issues)
            JFactory::getApplication()->enqueueMessage('Error: ' . $e->getMessage(), 'error');
            return false;
        }
    }

    /**
     * Validates the contact form data
     *
     * @param   string  $name     Name of the user
     * @param   string  $email    Email of the user
     * @param   string  $message  The message content
     *
     * @return  bool  True if all fields are valid, false if any are invalid
     */
    public static function validateForm($name, $email, $message)
    {
        // Check if all required fields are filled
        if (empty($name) || empty($email) || empty($message)) {
            JFactory::getApplication()->enqueueMessage('Please fill in all fields.', 'warning');
            return false;
        }

        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            JFactory::getApplication()->enqueueMessage('Please enter a valid email address.', 'warning');
            return false;
        }

        return true;
    }
}
