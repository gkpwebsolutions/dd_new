<?php
// No direct access
defined('_JEXEC') or die;

class ContactFormModelMessage extends JModelLegacy
{
    public function saveMessage($name, $email, $message)
    {
        // Get the database object
        $db = JFactory::getDbo();

    
        $query = $db->getQuery(true)
            ->insert($db->quoteName('w1h54__contact_messages'))
            ->columns($db->quoteName(array('name', 'email', 'message')))
            ->values($db->quote($name) . ',' . $db->quote($email) . ',' . $db->quote($message));

        
        $db->setQuery($query);

        try {
            $db->execute(); 
            return true;
        } catch (Exception $e) {

            // Handle errors
            JFactory::getApplication()->enqueueMessage('Error: ' . $e->getMessage(), 'error');
            return false;
        }
    }
}
 
