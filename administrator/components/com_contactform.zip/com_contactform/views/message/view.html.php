<?php
// No direct access
defined('_JEXEC') or die;

class ContactFormViewMessage extends JViewLegacy
{
    function display($tpl = null)
    {
        // Get the form object from the model if needed
        // $model = $this->getModel();
        // $this->form = $model->getForm();

        // Display the template
        parent::display($tpl);
    }
}
