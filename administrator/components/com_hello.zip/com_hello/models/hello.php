<?php
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\FormModel;

class HelloModelHello extends FormModel
{
    public function getForm($data = array(), $loadData = true)
    {
        $options = array('control' => 'jform', 'load_data' => $loadData);
        $form = $this->loadForm('com_hello.hello', 'hello', $options);

        if (empty($form)) {
            return false;
        }

        return $form;
    }

    public function save($data)
    {
        // Get the database connection
        $db = Factory::getContainer()->get('DatabaseDriver');
        $obj = (object) $data;

        try {
            // Check if we are updating or inserting
            if (isset($obj->id) && !empty($obj->id)) {
                // Update the existing record
                $db->updateObject('w1h54_healthpackages', $obj, 'id');
            } else {
                // Insert new record
                $db->insertObject('w1h54_healthpackages', $obj, 'id');
            }
        } catch (\RuntimeException $exc) {
            // Log the error message
            Factory::getApplication()->enqueueMessage($exc->getMessage(), 'error');
            return false;
        }

        return true;
    }

    public function getItem()
    {
        $app = Factory::getApplication();
        $input = $app->input;

        // Get the item id (cid) from the request
        $pk = $input->get('cid', array(), 'array');

        if (is_array($pk)) {
            $pk = (int) $pk[0];
        }

        if ($pk === 0) {
            return false;
        }

        // Get the database connection
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true);
        $query->select('*')
              ->from($db->quoteName('w1h54_healthpackages'))
              ->where($db->quoteName('id') . ' = ' . $db->quote($pk));

        $db->setQuery($query);

        try {
            $result = $db->loadObject();
        } catch (RuntimeException $exe) {
            // Handle error and enqueue message
            Factory::getApplication()->enqueueMessage($exe->getMessage(), 'error');
            return false;
        }

        return $result;
    }

    public function delete($id)
    {
        // Get the database connection
        $db = Factory::getContainer()->get('DatabaseDriver');
        $query = $db->getQuery(true);

        try {
            // Prepare delete query
            $query->delete('w1h54_healthpackages')
                  ->where($db->quoteName('id') . ' = ' . $db->quote($id));
            $db->setQuery($query);
            $db->execute();
        } catch (RuntimeException $exc) {
            // Log error message
            Factory::getApplication()->enqueueMessage($exc->getMessage(), 'error');
            return false;
        }

        return true;
    }

    protected function loadFormData()
    {
        // Load form data (for editing)
        $data = $this->getItem();
        return $data;
    }
}
