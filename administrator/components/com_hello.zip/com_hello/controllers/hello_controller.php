<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\MVC\Controller\BaseController;

class HelloController extends BaseController
{
    function display($cachable = false, $urlparams = array()) 
    {
        $app = Factory::getApplication();
        $app->input->set('view', 'hellos');
        parent::display($cachable, $urlparams); 
    }

    function add() 
    {
        $app = Factory::getApplication();
        $app->input->set('view', 'hello');
        parent::display();
    }

    public function edit()
    {
        $app = Factory::getApplication();
        $app->input->set('view', 'hello');
        parent::display();
    }

    function delete() 
    {
        $app = Factory::getApplication();

        // Check CSRF token
        Session::checkToken() or die("Invalid Token");

        $input = $app->input;
        $cid = $input->get('cid', array(), 'array');

        // Get the model
        $model = $this->getModel('hello');

        // Initialize error array
        $errors = array();

        // Loop through each selected item and try to delete
        foreach ($cid as $id) {
            if (!$model->delete($id)) {
                $errors[] = 'Delete failed for ID: ' . $id;
            }
        }

        // Check if there are any errors, if so, show them
        if (!empty($errors)) {
            Factory::getApplication()->enqueueMessage(implode(', ', $errors), 'warning');
        } else {
            $this->setMessage('Deleted successfully');
        }

        // Redirect back to the list view
        $this->setRedirect(Route::_('index.php?option=com_hello&view=hellos', false));
    }

    public function save()
    {
        // Check CSRF token
        if (!Session::checkToken('post')) {
            throw new \Exception('Invalid Token');
        }

        // Get the data from the form
        $data = $this->input->post->get('jform', array(), 'array');

        // Get the model
        $model = $this->getModel('hello');

        try {
            if ($model->save($data)) {
                $this->setMessage('Save successfully');
            } else {
                throw new \Exception('Save failed');
            }
        } catch (\Exception $e) {
            $this->setMessage('Save failed: ' . $e->getMessage(), 'error');
        }

        // Redirect back to the correct view (edit or add view after saving)
        $this->setRedirect(Route::_('index.php?option=com_hello&view=hello', false));
    }
}
