CREATE TABLE IF NOT EXISTS `w1h54_healthpackages` (
    `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `detail` TEXT,
    -- Add other columns as needed
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);