<?php
defined('_JEXEC') or die;
?>

<div class="custom-admin-module">
    <h3>Data from the Backend:</h3>
    <ul>
        <?php foreach ($data as $item): ?>
            <li><?php echo htmlspecialchars($item->title); ?></li>
        <?php endforeach; ?>
    </ul>
</div>
