<?php
defined('_JEXEC') or die;

class ModCustomAdminModuleHelper
{
    public static function getData()
    {
        // Fetch some data or perform some action for the administrator area
        $db = JFactory::getDbo();
        $query = $db->getQuery(true)
            ->select($db->quoteName('title'))
            ->from($db->quoteName('w1h54_healthpackages'))
            ->where($db->quoteName('state') . ' = 1');
        $db->setQuery($query);
        return $db->loadObjectList(); // Example: return published articles
    }
}
