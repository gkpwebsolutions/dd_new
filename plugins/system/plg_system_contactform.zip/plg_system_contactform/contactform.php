<?php
defined('_JEXEC') or die;

class PlgSystemContactform extends JPlugin
{
    public function onAfterRoute()
    {
        // Check if the form has been submitted
        if (JFactory::getApplication()->input->getCmd('task') === 'send_message') {

            // Get form data
            $name = JFactory::getApplication()->input->getString('name');
            $email = JFactory::getApplication()->input->getString('email');
            $message = JFactory::getApplication()->input->getString('message');

            // Sanitize input data
            $name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
            $email = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
            $message = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');

            // Validate email address
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                JFactory::getApplication()->enqueueMessage(JText::_('INVALID_EMAIL'), 'error');
                return;
            }

            // Insert data into the database
            $db = JFactory::getDbo();
            $query = $db->getQuery(true);

            $columns = array('name', 'email', 'message', 'created_at');
            $values = array($db->quote($name), $db->quote($email), $db->quote($message), $db->quote(JFactory::getDate()->toSql()));

            $query
                ->insert($db->quoteName('am__contact_messages'))
                ->columns($db->quoteName($columns))
                ->values(implode(',', $values));

            $db->setQuery($query);

            // Execute the query
            if ($db->execute()) {
                JFactory::getApplication()->enqueueMessage(JText::_('MESSAGE_SENT_SUCCESSFULLY'), 'message');
            } else {
                JFactory::getApplication()->enqueueMessage(JText::_('ERROR_SENDING_MESSAGE'), 'error');
            }
        }
    }
}
