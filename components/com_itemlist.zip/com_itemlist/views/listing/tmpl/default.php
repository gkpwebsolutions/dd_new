<?php
    // No direct access
    defined('_JEXEC') or die;
?>

<div class="container">
    <h2 class="text-center bg-success text-white">Item List</h2>
    <div class="row">
        <?php if (!empty($this->allItems)): ?>
            <?php foreach ($this->allItems as $item): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">
                                <!-- Link to the item detail page -->
                                <a href="<?= JRoute::_('index.php?option=com_itemlist&view=itemdetail&id=' . $item->id) ?>" class="text-decoration-none">
<?= htmlspecialchars($item->name) ?>
</a>


                            </h5>

                            <!-- Item Image -->
                            <div class="item-image-container mb-3">
                                <?php if (!empty($item->image_path)): ?>
                                    <img src="<?= JURI::root() . $item->image_path ?>" alt="Item Image" class="img-fluid" />
                                <?php else: ?>
                                    <p>No Image</p>
                                <?php endif; ?>
                            </div>

                            <!-- Item Description -->
                            <p class="card-text"><?= $item->description ?></p>

                            <!-- MRP and Offer Price -->
                            <p><strong>MRP:</strong> <?= $item->mrp ?></p>
                            <p><strong>Offer Price:</strong> <?= $item->offer_price ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
        <?php else: ?>
            <div class="col-12">
                <p class="text-center text-danger">Record Not Found</p>
            </div>
        <?php endif; ?>
    </div>
</div>


<!-- Include Bootstrap and jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<script>
    $(document).ready(function(){  
        
        // Delete item functionality
        $(".deleteBtn").click(function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this item?')) {
                let Url = this.href;
                $.ajax({
                    type: "POST",
                    url: Url,
                    data: {},
                    success: function(response) {
                        if(response.status === true){
                            $('#message').text(response.message).addClass('bg-success');
                            setTimeout(() => {
                                window.location.href = "<?php echo JURI::base() ?>" + "index.php?option=com_itemlist";
                            }, 1000);
                        } else {
                            $('#message').text(response.message).addClass('bg-danger');
                        }
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
            }
        });

        // Handle "Select All" checkbox
        $('#selectAll').click(function() {
            $('input[name="inputItem[]"]').prop('checked', this.checked);
        });

        // Handle "Select Delete" action
        $('#selectdelete').click(function() {
            let selectedItems = $('input[name="inputItem[]"]:checked').map(function() {
                return $(this).attr('id');
            }).get();

            if (selectedItems.length === 0) {
                alert('No items selected');
                return;
            }

            if (confirm('Are you sure you want to delete the selected items?')) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo JURI::base()?>index.php?option=com_itemlist&format=json&task=selectdelete.selectItems&id=" + selectedItems,
                    data: {},
                    success: function(response) {
                        if (response.status === true) {
                            $('#message').text(response.message).addClass('bg-success');
                            setTimeout(() => {
                                window.location.href = "<?php echo JURI::base()?>index.php?option=com_itemlist";
                            }, 1000);
                        } else {
                            $('#message').text(response.message).addClass('bg-danger');
                        }
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
            }
        });
    });
</script>
