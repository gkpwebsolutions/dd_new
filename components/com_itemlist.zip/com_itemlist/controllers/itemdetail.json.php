<?php

// No direct access
defined('_JEXEC') or die;

// Import Joomla controller library
use Joomla\CMS\Factory; // Add this line for the correct Factory namespace

class ItemlistControllerItemDetail extends JControllerLegacy {

    // Method to display the item details
    public function display($cachable = false, $urlparams = false) {
        // Get the input from the request
        $input = Factory::getApplication()->input;
        $itemId = $input->getInt('id', 0);  // Get the 'id' parameter from the URL

        if ($itemId == 0) {
            // If the ID is not valid, redirect or show an error message
            Factory::getApplication()->enqueueMessage('Invalid item ID.', 'error');
            return;
        }

        // Fetch the item details from the database
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
                    ->select('*')
                    ->from('#__healthpackages')  // Ensure this is the correct table name
                    ->where('id = ' . (int) $itemId);
        $db->setQuery($query);
        $item = $db->loadObject();  // Use loadObject() to fetch a single item object

        if (!$item) {
            // If no item is found, show an error message
            Factory::getApplication()->enqueueMessage('Item not found.', 'error');
            return;
        }

        // Pass the item object to the view
        $view = $this->getView('ItemDetail', 'html');
        $view->assign('item', $item);  // Assign the single item object to the view

        // Display the view
        parent::display();
    }
}
